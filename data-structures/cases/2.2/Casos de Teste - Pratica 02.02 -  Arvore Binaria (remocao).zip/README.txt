Arquivo zip gerado em: 21/06/2023 10:53:25 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Prática 02.02 -  Árvore Binária (remoção)