Arquivo zip gerado em: 28/06/2023 20:59:11 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Prática 03.02 - Insertion Sort