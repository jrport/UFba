Arquivo zip gerado em: 27/06/2023 17:38:29 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Prática 03.03 - Bubble Sort